using Microsoft.Win32;
using System.Diagnostics;
using System.Security.Principal;
//Cole T
namespace Dental_IT_Worker_Service
{
    public class Worker : BackgroundService
    {
        private const string SourceName = "MySessionChangedEvent";
        private const string LogName = "MyLog";
        private readonly ILogger<Worker> Logger;

        public Worker(ILogger<Worker> logger)
        {
            Logger = logger;

            //Admin privileges are required to make changes
            //to the event log (checking & adding sources)
            if (!HasRequiredPermissions())
            {
                WriteToConsole("Error: Admin privileges required! Closing in 5 seconds.", true);
                Thread.Sleep(5000);
                Environment.Exit(0);
                return;
            }

            if (!EventLog.SourceExists(SourceName))
            {
                EventLog.CreateEventSource(SourceName, LogName);
                WriteToConsole("Event source created! Please allow for some time for this to take affect", false);
            }

            SystemEvents.SessionSwitch += SystemEvents_SessionSwitch;
        }

        /// <summary>
        /// Validates the application's administrator permissions
        /// </summary>
        /// <returns>true if application has administrator permissions, otherwise false</returns>
        private bool HasRequiredPermissions()
        {
            using (WindowsIdentity identity = WindowsIdentity.GetCurrent())
            {
                WindowsPrincipal principle = new WindowsPrincipal(identity);
                if (principle.IsInRole(WindowsBuiltInRole.Administrator))
                    return true;
                else
                    return false;
            }
        }

        private void SystemEvents_SessionSwitch(object sender, SessionSwitchEventArgs e)
        {
            LogEvent(e.Reason.ToString());
            WriteToConsole($"Session change: {e.Reason}", false);
        }

        /// <summary>
        /// Writes a message to the on-screen console
        /// </summary>
        /// <param name="message">Contents of the message</param>
        /// <param name="error">represents if the message type is an error type</param>
        private void WriteToConsole(string message, bool error)
        {
            if (error)
                Logger.LogError($"[{DateTimeOffset.UtcNow}] {message}");
            else
                Logger.LogInformation($"[{DateTimeOffset.UtcNow}] {message}");
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            WriteToConsole("Service Started", false);
        }

        /// <summary>
        /// Writes to the Event Log
        /// </summary>
        /// <param name="entry">Contents of the log</param>
        /// <param name="logType">Represents the log type of the entry</param>
        private void LogEvent(string entry, EventLogEntryType logType = EventLogEntryType.Information)
        {
            try
            {
                using (EventLog log = new EventLog())
                {
                    log.Source = SourceName;
                    log.WriteEntry(entry, logType);
                }
            }
            catch (Exception e)
            {
                WriteToConsole($"Erorr writing to Windows log file {e.Message}", true);
            }
        }
    }
}
